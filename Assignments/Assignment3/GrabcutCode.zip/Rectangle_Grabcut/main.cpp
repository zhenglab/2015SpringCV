#include <iostream>
#include <cv.hpp>
#include <highgui.hpp>
#include <features2d/features2d.hpp>
#include <xfeatures2d.hpp>
#include <core.hpp>
#include <imgproc.hpp>
#include <imgcodecs.hpp>
#include <sstream>

using namespace std;
using namespace cv;

string itos(int i)   // 将int 转换成string
{
    stringstream s;
    s << i;
    return s.str();
}


int main(int, char* argv[])
{
        Mat mOriginImg=imread(argv[1],1);                  //输入原始图像
        Mat mSaMap=imread(argv[2],0);                       //输入saliency map的二值图像

        const int nRow=mOriginImg.rows;
        const int nCol=mOriginImg.cols;
        imshow("OriginImage", mOriginImg);
        waitKey();
        imshow("SaliencyMap", mSaMap);
        waitKey();


        //~~~~~~~~~~~~~~~~Draw Rectangle~~~~~~~~~~~~~~~~~~~~//
        int i=0,j=0;
        int nRowMin=0, nRowMax=0, nColMin=0, nColMax=0;

        vector<int> width;
        vector<int> height;
        for(i=0; i<nRow; i++)
                for(j=0; j<nCol; j++)
                {
                        if(mSaMap.at<uchar>(i,j)==255)
                        {
                                width.push_back(j);
                                height.push_back(i);
                        }
                }

        nRowMin=height[0];
        nRowMax=height[0];
        for(i=0;i<height.size();i++)
        {
                if(nRowMin>height[i])
                        nRowMin=height[i];
                if(nRowMax<height[i])
                        nRowMax=height[i];
        }
        nColMin=width[0];
        nColMax=width[0];
        for(i=0;i<width.size();i++)
        {
                if(nColMin>width[i])
                        nColMin=width[i];
                if(nColMax<width[i])
                        nColMax=width[i];
        }

        Mat mDrawRec=mOriginImg.clone();
        Point2f pRecLeftUp,pRecRightDown;
        pRecLeftUp=cvPoint(nColMin,nRowMin);
        pRecRightDown=cvPoint(nColMax,nRowMax);
        rectangle( mDrawRec, pRecLeftUp,pRecRightDown, Scalar(0, 255, 0), 2);
        imshow("Rectangle", mDrawRec);
        waitKey();


        //~~~~~~~~~~~~~~~~Implement grab cut~~~~~~~~~~~~~~~~~~~~//
        Rect rect(pRecLeftUp,pRecRightDown);
        Mat OutMask(mOriginImg.size(), CV_8UC1);
        Mat BgdModel, FgdModel;

        int nIteration=5;
        Mat mask;
        Mat obj;
        bool isInitialized=false;

        for(i=0; i<nIteration; i++)
        {
                if(!isInitialized)
                {
                        grabCut(mOriginImg, OutMask, rect, BgdModel, FgdModel, 1, GC_INIT_WITH_RECT);
                        isInitialized=true;
                }
                else
                {
                        grabCut(mOriginImg, OutMask, rect, BgdModel, FgdModel, 1);
                }
        }
        compare(OutMask, GC_PR_FGD, mask, CMP_EQ);
        mOriginImg.copyTo(obj, mask);
        imshow("obj", obj);
        waitKey();

    //~~~~~~~~~~~~~~~~Show segmentation result~~~~~~~~~~~~~~~~~~~~//
        Mat  mSegBinary=obj.clone();
        cvtColor(mSegBinary,mSegBinary,CV_RGB2GRAY);
        for(i=0;i<nRow;i++)
            for(j=0;j<nCol;j++)
            {
                    if(mSegBinary.at<uchar>(i,j)>0)
                            mSegBinary.at<uchar>(i,j)=255;
            }
        imshow("SegmentationResult",mSegBinary);
        waitKey(0);

    return 0;

}
