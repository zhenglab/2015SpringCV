clear all;
clc;
close all;

picstr=dir('E:\meanshift\BSDS500\data\images\train\*.jpg');
m=length(picstr);

for hs=10:5:40
    for hr=10:10:90
        for i=1:m
            if picstr(350).name(1)=='.'  %ȥ�������ļ�
            continue;
            end 
            filename=strcat('E:\meanshift\BSDS500\data\images\train\',picstr(350).name);
            x=imread(filename);
            th=0.1;
            hr=10;
            hs=10;
            iteration=5;
            [y, MS] = meanShiftPixCluster(x,hs,hr,th,iteration);
            img_ms=uint8(y);
            fname_img=strcat('E:\meanshift\BSDS500\data\images\train_img','\','hs_',num2str(hs),'\','hr_',num2str(hr),'\');
            fname_lab=strcat('E:\meanshift\BSDS500\data\images\train_lab','\','hs_',num2str(hs),'\','hr_',num2str(hr),'\');
            fname_img1=['E:\meanshift\BSDS500\data\images\train_img\','hs_',num2str(hs),'\','hr_',num2str(hr),'\'];
            fname_lab1=['E:\meanshift\BSDS500\data\images\train_lab\','hs_',num2str(hs),'\','hr_',num2str(hr),'\'];
            mkdir(fname_img);
            mkdir(fname_lab);
            fname_img1=strcat(fname_img,picstr(350).name);
            fname_lab1=strcat(fname_lab,picstr(350).name(1:end-4),'.mat');
            
            imwrite(img_ms,fname_img1);
           
            imgInf = processSuperpixelImage(y);
            label_result = double(imgInf.segimage);   %���
            fid_lab=fopen(fname_lab1,'wt');
            fwrite(fid_lab,label_result);
            fclose(fid_lab);
        end
    end 
 end
